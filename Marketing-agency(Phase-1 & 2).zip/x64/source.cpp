#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <stdlib.h>
#include "../Client.h" //header file of client management
#include "../Campaign.h" //header file of campaign management
#include "../Task.h" //header file of task management
#include "../social_media_post.h" //header file of social media management
#include "../customer.h" //header file of customer management(new for phase-2)
#include "../event_manager.h" //header file of event management(new for phase-2)
#include "../Rating.h" //header file of customer rating analysis(new for phase-2)
using namespace std;

//main menu
void main_menu() {
	int choice;
	system("cls");
	cout << "             MARKETING AGENCY                    " << endl;
	cout << "-------------------------------------------------" << endl;
	cout << "1. Client Management" << endl;
	cout << "2. Campaign Management" << endl;
	cout << "3. Task Management" << endl;
	cout << "4. Social Media Management" << endl;
	cout << "5. Generate the total revenue of the client" << endl;
	cout << "6. Customer Management" << endl;
	cout << "7. Event Management " << endl;
	cout << "8. Customer Rating Analysis" << endl;
	cout << "9. Quit" << endl << endl;
	cout << "Select the option:";
	cin >> choice;
	switch (choice) {
	case 1:
		client_menu(); //client management system using linked list
		break;
	case 2:
		campaign_menu(); //campaign management system using array
		break;
	case 3:
		task_menu(); //task management system using queue
		break;
	case 4:
		social_menu(); //social media manaagement system using stack
		break;
	case 5:
		revenue(); //generate the revenue of the particular client using reading the file 
		break;
		// 
		// New For Phase 2
		//
	case 6:
		customer_menu(); //customer management using hashing
		break;
		// 
		// New For Phase 2
		//
	case 7:
		event_menu(); //event management using sets
		break;
		// 
		// New For Phase 2
		//
	case 8:
		rating_menu(); //customer rating management using graph
		break;
		// 
		// New For Phase 2
		//
	case 9:
		break;
	default:
		cout << "please select valid option...";
		break;
	}
}
int main()
{
	main_menu(); //main console menu
	return 0;
}